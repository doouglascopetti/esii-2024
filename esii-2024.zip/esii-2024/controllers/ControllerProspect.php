<?php
    namespace controllers;

    require_once('../DAO/DAOProspect.php');

    use DAO\DAOProspect;

    /**
     * Esta classe é responsavel por fazer o tratamento dos dados para apresentação e/ou envio para a DAO executar as consultas no BD.
     * Seu escopo se limita as funções da entidade prospect.
     * 
     * @author Douglas
     */
    class ControllerProspect{
        /**
         * Recebe um objeto do tipo prospect, verifica se é para salvar ou alterar e envia para a DAO executar a operação.
         * @param Prospect
         * @return TRUE|Exception Retorna TRUE caso a operação seja bem sucedida e exception caso não tenha. 
         */
        public function salvarProspect($prospect){
            $daoProspect = new DAOProspect();

            if($prospect->codigo === null) {
                try{
                    $daoProspect->incluirProspect($prospect->nome, $prospect->email, $prospect->celular, $prospect->facebook, $prospect->whatsapp);

                    unset($daoProspect);
                    return TRUE;
                }catch(\Exception $e){
                    throw new \Exception($e->getMessage());
                }
            } else {
                try{
                    $daoProspect->atualizarProspect($prospect->nome, $prospect->email, $prospect->celular, $prospect->facebook, $prospect->whatsapp, $prospect->codigo);

                    unset($daoProspect);
                    return TRUE;
                } catch(\Exception $e){
                    throw new \Exception($e->getMessage());
                }
            }
        }
        /**
         * Recebe um objeto do tipo prospect, verifica se é para excluir e envia para a DAO executar a operação.
         * @param Prospect
         * @return TRUE|Exception Retorna TRUE caso a operação seja bem sucedida e exception caso não tenha. 
         */
        public function excluirProspect($prospect){
            $daoProspect = new DAOProspect();
            try{
                $daoProspect->excluirProspect($prospect->codigo);

                unset($daoProspect);
                return TRUE;
            }catch(\Exception $e){
                throw new \Exception($e->getMessage());
            }
        }

        /**
         * Método para buscar os prospects por e-mail, se não for informado o email serão retornados todos.
         * @param String|null 
         * @return Prospect[]
         */

         public function buscarProspects($email=null){
            $daoProspect = new DAOProspect();
            $prospects = array();

            if($email === null){
                $prospects = $daoProspect->buscarProspects();

                unset($daoProspect);
                return $prospects;
            } else {
                $prospects = $daoProspects->buscarProspects($email);
                
                unset($daoProspect);
                return $prospects;
            }
         }
    }
?>