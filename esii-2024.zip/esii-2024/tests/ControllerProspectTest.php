<?php
namespace test;
require_once('../libs/vendor/autoload.php');
require_once('../models/Prospect.php');
require_once('../controllers/ControllerUsuario.php');

use PHPUnit\Framework\TestCase;
use MODELS\Prospect;
use controllers\ControllerProspect;

class ControllerProspectTest extends TestCase{

   /** @test */
   public function incluirProspect(){
      $ctrlProspect = new ControllerProspect();
      $this->assertEquals(
         TRUE,
         $ctrlProspect->incluirProspect('Paulo Roberto Cordova', 'paulo@eu.com.br', '(49)96633-9988', 'facepaulo', '(49)8899-6699')
      );

      unset($ctrlProspect);
   }
   /** @test */
   public function atualizarProspect(){
      $ctrlProspect = new ControllerProspect();
      $this->assertEquals(
         TRUE,
         $ctrlProspect->atualizarProspect('Paulo Roberto Cordova', 'paulo@gmail.com.br', '(49)96633-9988',  'facepaulo', '(49)8899-6699', 3)
      );
      unset($ctrlProspect);
   }
   /** @test */
   public function excluirProspect(){
      $ctrlProspect = new ControllerProspect();
      $this->assertEquals(
         TRUE,
         $ctrlProspect->excluirProspect(2)
      );
      unset($ctrlProspect);
   }
   /** @test */
   public function buscarTodosProspectTest(){
      $ctrlProspect = new ControllerProspect();

      $arrayComparar = array();

      $conn = new \mysqli('localhost', 'root', '', 'bd_prospects');
      $sqlBusca = $conn->prepare("select cod_prospect, nome, email, celular,
                                          facebook, whatsapp
                                          from prospect");
      $sqlBusca->execute();
      $result = $sqlBusca->get_result();
      if($result->num_rows !== 0){
         while($linha = $result->fetch_assoc()) {
            $linhaComparar = new Prospect();
            $linhaComparar->addProspect($linha['cod_prospect'], $linha['nome'], $linha['email'], $linha['celular'],
                                   $linha['facebook'], $linha['whatsapp']);
            $arrayComparar[] = $linhaComparar;
         }
      }

      $this->assertEquals(
         $arrayComparar,
         $ctrlProspect->buscarProspects()
      );
      unset($ctrlProspect);
      unset($linhaComparar);
      $sqlBusca->close();
      $conn->close();
   }
   /** @test */
   public function buscarProspectPorEmailTest(){
      $ctrlProspect = new ControllerProspect();
      $arrayComparar = array();
      $emailProspect = 'gernunes@hotmail.com';

      $conn = new \mysqli('localhost', 'root', '', 'bd_prospects');
      $sqlBusca = $conn->prepare("select cod_prospect, nome, email, celular,
                                          facebook, whatsapp
                                          from prospect
                                          where
                                          email = '$emailProspect'");
      $sqlBusca->execute();
      $result = $sqlBusca->get_result();
      if($result->num_rows !== 0){
        while($linha = $result->fetch_assoc()) {
            $linhaComparar = new Prospect();
            $linhaComparar->addProspect($linha['cod_prospect'], $linha['nome'], $linha['email'], $linha['celular'],
                                   $linha['facebook'], $linha['whatsapp']);
            $arrayComparar[] = $linhaComparar;
         }
      }

      $this->assertEquals(
         $arrayComparar,
         $ctrlProspect->buscarProspects($emailProspect)
      );
      unset($ctrlProspect);
      unset($linhaComparar);
      $sqlBusca->close();
      $conn->close();
   }
}
?>