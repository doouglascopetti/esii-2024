<?php
require_once('../libs/vendor/autoload.php');
require_once('../models/Usuario.php');
require_once('../controllers/ControllerUsuario.php');

use PHPUnit\Framework\TestCase;
use models\Usuario;
use controllers\ControllerProspect;

class ControllerUsuarioTest extends TestCase{
    /** @test */
    public function testLogar(){
        $ctrlUsuario = new ControllerUsuario();
        $usuario = new Usuario();
        $usuario->addUsuario("paulo", "Paulo Roberto Córdova", "paulo@eu.com.br", "(99)9999-9999", TRUE);

        $this->assertEquals(
            $usuario,
            $ctrlUsuario->fazerLogin('paulo', '123')
        );
    }

    /** @test */
    public function testIncluirUsuario(){
        $ctrlUsuario = new ControllerUsuario();
        $this->assertEquals(
        TRUE,
        $ctrlUsuario->incluirUsuario("raul", "raul@gmail.com", "raul", "raul")
        );
        unset($usuario);
 }
}
?>